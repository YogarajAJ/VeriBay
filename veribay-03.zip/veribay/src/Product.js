import React from 'react'
import Home from './Home';

export default class Product extends React.Component {

    constructor(props) {
        super(props)
        this.state = {
            flag: false
        }
    }

    backButton = () => {
        this.setState({
            flag: true
        }
        )
    }

    render() {

        let product_description = this.props.allProducts[this.props.productId]
        console.log(product_description)

        return (
            <div>
                {
                    (this.state.flag) ? <Home /> :
                        <div>
                            <button className="btn btn-secondary btn-md" onClick={this.backButton}> <h5>{"<--"}Back</h5></button>
                            <div className="container">
                                <hr />
                                <div className="card">
                                    <div className="row">
                                        <div className="column left" >
                                            <img src={require("" + product_description.image)} />
                                        </div>
                                        <div className="column right" >
                                            <h3> {product_description.prod_name}</h3>
                                            {product_description.prod_description}<br />
                                            <h5> {product_description.price}</h5>
                                            <button className="btn btn-outline-primary" >Buy Now</button>&nbsp;&nbsp;
                                            <button className="btn btn-outline-primary " >Add to cart</button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                        </div>
                                    </div>
                                </div>
                                <br />
                            </div>
                        </div>
                }
            </div>
        )
    }
}