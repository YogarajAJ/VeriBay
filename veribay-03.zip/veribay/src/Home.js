import React from 'react';
import './styles.css';
import Product from './Product';

export default class Home extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            bay: [
                { prod_name: 'cartoon books', prod_description: 'Cards that show cryptocurrency-related data, including a chart. Can be used for showing other data, such as fiat currency or stock market prices.', image: './assets/one.jpg', price: '$2000' },
                { prod_name: 'Kitchen utensils', prod_description: 'Cards that show cryptocurrency-related data, including a chart. Can be used for showing other data, such as fiat currency or stock market prices.', image: './assets/two.jpg', price: '$2000' },
                { prod_name: 'Hand bag', prod_description: 'Cards that show cryptocurrency-related data, including a chart. Can be used for showing other data, such as fiat currency or stock market prices.', image: './assets/three.jpg', price: '$2000' },
                { prod_name: 'Shoes', prod_description: 'Cards that show cryptocurrency-related data, including a chart. Can be used for showing other data, such as fiat currency or stock market prices.', image: './assets/four.jpg', price: '$2000' },
                { prod_name: 'Ladies kurthis', prod_description: 'Cards that show cryptocurrency-related data, including a chart. Can be used for showing other data, such as fiat currency or stock market prices.', image: './assets/five.jpg', price: '$2000' }
            ]
        }
    }

    displayProduct = (event) => {
        
        this.setState({
            showProduct: true,
            productId:event.target.name
        })
    }

    render() {

        let list = this.state.bay.map(
            (i, id) => (
                <div key={id} className="container">
                    <hr />
                    <div className="card">
                        <div className="row">
                            <div className="column left" >
                                <img src={require("" + i.image)} />
                            </div>
                            <div className="column right" >
                                <h3> {i.prod_name}</h3>
                                {i.prod_description}<br />
                                <h5> {i.price}</h5>
                                <button className="btn btn-outline-primary" >Buy Now</button>&nbsp;&nbsp;
                                 <button className="btn btn-outline-primary " >Add to cart</button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                 <button className="btn btn-outline-primary " name={id} onClick={this.displayProduct
                                } >More Info -></button>
                            </div>
                        </div>
                    </div>
                    <br />
                </div>

            )
        );
        return (
            <div>
                {(this.state.showProduct) ? <Product allProducts = {this.state.bay} productId={this.state.productId} setFlag={this.displayProduct} /> : list}
            </div>
        )
    }
}

