import React from 'react' 

export default class NoPageFound extends React.Component {
    render(){
        return(
            <div>
                Page Not Fount
            </div>
        )
    }
}