import React from 'react'

import { Link } from 'react-router-dom'
import { Navbar, Nav } from 'react-bootstrap'

export default class NavbarComponent extends React.Component {
    
    constructor(props){
        super(props);
        this.state = {
            flag:true
        }
    }

    render() {
        return (
            <Navbar bg="dark" variant="dark">

                <Navbar.Brand>
                    <Link to="/"><button style={{ color: "red" }} className="btn btn-lg">VeriBay</button> </Link>
                </Navbar.Brand>

                <Nav style={{ paddingRight: '2%' }} className="ml-auto">
                    <Nav.Link >
                        <Link to="/login"><button className="btn btn-dark btn-md"><h5>Login</h5></button></Link>
                    </Nav.Link>                    
                </Nav>

            </Navbar>
        )
    }
}