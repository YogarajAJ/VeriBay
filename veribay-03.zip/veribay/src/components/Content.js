import React from 'react'

import { Switch, Route } from 'react-router-dom'
import Login from './Login'
import Home from '../Home'
import Product from '../Product';

export default class Content extends React.Component {

    constructor(props){
        super(props);
        this.state = {
            routerFlag:true
        }
    }

    changeFlag = () => {
        console.log("true")
    }

    render() {
        return (
            <Switch>
                <Route path="/login" component={Login} />
                <Route path="/" component={Home} />
                <Route path="/product" component={Product} />
            </Switch>
        )
    }
}