import React from 'react';
import NavbarComponent from './components/NavbarComponent';
import Content from './components/Content';


export default class App extends React.Component {
  render() {
    return (
      <div className="App">
        <NavbarComponent />
        <Content />
      </div>
    )
  }
}

