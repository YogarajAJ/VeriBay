import React from 'react'

import { Button, Modal, Form, Row, Col } from 'react-bootstrap'

export default class Login extends React.Component {

    constructor() {
        super();
        this.state = {
            showModal: true,
            registerShowButton: false,
            loginShowButton: true
        }
    }

    handleChange = (event) => {
        this.setState({
            [event.target.name]: event.target.value
        })
    }

    handleLoginClick = () => {
        console.log(this.state.username, this.state.password)
        this.close()
    }

    handleLoginToRegisterClick = () => {
        console.log("te")
        this.setState({
            registerShowButton: !this.state.registerShowButton
        })
    }

    open(modalType) {
        this.setState({
            showModal: !this.state.showModal,
            modalType: modalType
        });
    }

    close() {
        this.setState({ showModal: !this.state.showModal });
        
    }

    registerUserClick = () => {
        console.log(this.state.username, this.state.password, this.state.city)
        this.close()
    }
    
    render() {

        return (
            <div>
               { this.state.loginShowButton && <Modal show={this.state.showModal} onHide={this.close.bind(this)}>
                    <Modal.Header closeButton>
                        <Modal.Title>Login</Modal.Title>
                    </Modal.Header>
                    <Modal.Body>
                        <Form>
                            <Form.Group as={Row} controlId="formPlaintextEmail">
                                <Form.Label column sm="2">
                                    Email
                                </Form.Label>
                                <Col sm="10">
                                    <Form.Control onChange={this.handleChange} name="username" placeholder="email@example.com" />
                                </Col>
                            </Form.Group>

                            <Form.Group as={Row} controlId="formPlaintextPassword">
                                <Form.Label column sm="2">
                                    Password
                                </Form.Label>
                                <Col sm="10">
                                    <Form.Control type="password" name="password" onChange={this.handleChange} placeholder="Password" />
                                </Col>
                            </Form.Group>
                        </Form>
                    </Modal.Body>

                    <Modal.Footer>
                        <Button variant="primary" onClick={this.handleLoginClick}>Login</Button>
                        <Button variant="secondary" onClick={this.handleLoginToRegisterClick}>Register</Button>
                    </Modal.Footer>
                </Modal>}

                { this.state.registerShowButton && <Modal show={this.state.showModal} onHide={this.close.bind(this)}>
                    <Modal.Header closeButton>
                        <Modal.Title>Login</Modal.Title>
                    </Modal.Header>
                    <Modal.Body>
                        <Form>
                            <Form.Group as={Row} controlId="formPlaintextEmail">
                                <Form.Label column sm="2">
                                    Email
                                </Form.Label>
                                <Col sm="10">
                                    <Form.Control onChange={this.handleChange} name="username" placeholder="email@example.com" />
                                </Col>
                            </Form.Group>

                            <Form.Group as={Row} controlId="formPlaintextPassword">
                                <Form.Label column sm="2">
                                    Password
                                </Form.Label>
                                <Col sm="10">
                                    <Form.Control type="password" name="password" onChange={this.handleChange} placeholder="Password" />
                                </Col>
                            </Form.Group>

                            <Form.Group as={Row} controlId="formPlaintext">
                                <Form.Label column sm="2">
                                    City
                                </Form.Label>
                                <Col sm="10">
                                    <Form.Control type="text" name="city" onChange={this.handleChange} placeholder="City" />
                                </Col>
                            </Form.Group>
                        </Form>
                    </Modal.Body>

                    <Modal.Footer>
                        <Button variant="primary" onClick={this.registerUserClick}>Register</Button>
                    </Modal.Footer>
                </Modal>}


            </div>
        )
    }

}