import React from 'react'

import { Switch, Route } from 'react-router-dom'
import Login from './Login'

export default class Content extends React.Component {
    render() {
        return (
            <Switch>
                <Route path="/login" component={Login} />
            </Switch>
        )
    }
}