package com.veribay.user.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.veribay.user.model.Users;
import com.veribay.user.service.UserService;


@RestController
@CrossOrigin
public class UserController {
	
	@Autowired
	private UserService service;

	@PostMapping("/registerUser")
	public String registerUser(@RequestBody Users user) {
		service.registerUser(user);
		return "Registered Successfully with id : "+user.get_id();
	}
	
	@GetMapping("/getUsers")
	public List<Users> getAllUsers(){
		return service.getAllUsers();
	}
	
	
}
