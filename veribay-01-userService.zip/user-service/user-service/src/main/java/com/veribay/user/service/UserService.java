package com.veribay.user.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.veribay.user.model.Users;
import com.veribay.user.repository.UserRepository;

@Service
public class UserService {

	@Autowired
	private UserRepository repository;
	
	public String registerUser(Users user) {
		repository.save(user);
		return "Registered Successfully with id : "+user.get_id();
	}
	
	public List<Users> getAllUsers(){
		return repository.findAll();
	}
	

}
