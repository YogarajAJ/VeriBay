package com.veribay.user.repository;


import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;

import com.veribay.user.model.Users;

public interface UserRepository extends MongoRepository<Users, ObjectId>{

}
