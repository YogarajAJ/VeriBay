package com.veribay.product.repository;

import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;

import com.veribay.product.model.Product;

public interface ProductRepository extends MongoRepository<Product, ObjectId>{

}
