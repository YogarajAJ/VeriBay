import React from 'react'
import axios from 'axios'

export default class Home extends React.Component {

    constructor() {
        super()
        this.state = {
            productsList: []
        }
    }

    componentDidMount() {
        axios.get("http://localhost:8080/getAllProducts")
            .then(response => {
                this.setState({
                    productsList: response.data
                })
            }
            )
            .catch(error => console.log(error))
    }


    render() {

        let products = (this.state.productsList.length > 0) ? this.state.productsList.map(
            (product, id) =>
                <div key={id} >
                    <hr />
                    <div className="card">
                        <div className="row">
                            <div className="column left" >
                                
                            </div>
                            <div className="column right" >
                                <h3> {product.name}</h3>
                                {product.short_desc}<br />
                                <h5> {product.price}</h5>
                                <button className="btn btn-outline-primary" >Buy Now</button>&nbsp;&nbsp;
                                <button className="btn btn-outline-primary " >Add to cart</button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            </div>
                        </div>
                    </div>
                    <br />
                </div>

        ) : <div>

            </div>

        return (
            <React.Fragment>

                <div>
                    {products}
                </div>

            </React.Fragment>
        )
    }
}